package com.example.latihan_webservice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
